package Application

import javafx.scene.control.Label
import javafx.scene.shape.Rectangle

class Controller {

    public Label sta2Count
    public Rectangle Ox1


}
