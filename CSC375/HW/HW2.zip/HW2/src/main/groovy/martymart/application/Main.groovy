package martymart.application

import martymart.engine.datastore.Tree
import martymart.engine.models.Item


/**
 * Main class
 */
class Main {

    public static def main(args){

    }

}
