var Maths = (function(){
   
    return {
        
        degToRad:function(angle){
            return angle * Math.PI / 180.0
        }
    }
    
})()