package asteroidsfw

object Collidable extends GameSubSystem[Collidable] {
  def update(delta: Double) {
    val allArray = all.toArray
    for (i <- 0 until allArray.length; a1 = allArray(i); j <- i + 1 until allArray.length; a2 = allArray(j))
      if (a1 collidesWith a2)
        a1 resolveCollisionWith a2
  }
}

trait Collidable extends GameObject {
  private var lastCollision: Collidable = _

  Collidable + this

  override def destroy() {
    Collidable - this
    super.destroy()
  }

  final def resolveCollisionWith(other: Collidable) {
    if ((other != lastCollision) || (this != other.lastCollision)) {
      lastCollision = other
      other.lastCollision = this
      collide(other)
    }
  }

  def collidesWith(other: Collidable): Boolean
  def collide(other: Collidable): Unit
}

trait CollidableCircle extends Collidable {
  val radius: Int
  def collidesWith(other: Collidable): Boolean = other match {
    case that: CollidableCircle => {
      val diff = pos - that.pos
      val sumR = radius + that.radius
      diff.sqLength <= sumR * sumR
    }
  }
}
