package asteroidsfw

final case class Vector2d(x: Double, y: Double) {
  lazy val sqLength = x * x + y * y
  lazy val length = Math.sqrt(sqLength)

  def + (that: Vector2d) =
    new Vector2d(x + that.x, y + that.y)
  def - (that: Vector2d) = 
    new Vector2d(x - that.x, y - that.y)
  def unary_- =
    new Vector2d(-x, -y)
  def * (that: Double) =
    new Vector2d(that * x, that * y)
  def dot (that: Vector2d) =
    x * that.x + y * that.y
  //pseudo-cross in 2D, take the z-component only as a scalar
  def cross (that: Vector2d) =
    x * that.y - y * that.x

  def normalize =
    new Vector2d(x / length, y / length)

  def rotate(angle: Double) =
    new Vector2d(x * Math.cos(angle) - y * Math.sin(angle), y * Math.cos(angle) + x * Math.sin(angle))

  override def toString =
    "x: " + x + ", y: " + y
}
