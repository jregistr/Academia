package asteroidsfw.ai;

public interface Perceptions {
  public AsteroidPerception[] asteroids();
  public ShipPerception[] ships();
}
