package asteroidsfw.ai;

public interface ShipControl extends ShipPerception {
  public void thrustForward(boolean thrust);
  public void thrustBackward(boolean thrust);
  public void rotateLeft(boolean rotate);
  public void rotateRight(boolean rotate);
  public void shooting(boolean trigger);
}
