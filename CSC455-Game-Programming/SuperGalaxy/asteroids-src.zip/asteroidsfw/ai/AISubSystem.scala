package asteroidsfw.ai

import scala.collection.mutable.Map
import scala.collection.mutable.Set
import scala.actors.Actor

object AISubSystem extends GameSubSystem[ShipMind] {
  class ShipActor(mind: ShipMind) extends Actor {
    def act() {
      react {
        case (p: Percepts, delta: Double) =>
          mind.think(p, delta)
          act()
        case Shutdown =>
      }
    }
  }

  case class Percepts(asteroids: Array[AsteroidPerception], ships: Array[ShipPerception]) extends Perceptions
  case object Shutdown

  val allActors = Map[ShipMind, ShipActor]()

  override def + (mind: ShipMind) {
    super.+(mind)
    val actor = new ShipActor(mind)
    allActors += Pair(mind, actor)
    actor.start()
  }

  override def - (mind: ShipMind) {
    super.-(mind)
    val actor = allActors(mind)
    actor ! Shutdown
    allActors -= mind
  }

  override def shutdown() {
    for (actor <- allActors.values)
      actor ! Shutdown
  }

  def update(delta: Double) {
    for (actor <- allActors.values)
      actor ! (Percepts(Asteroid.all.toArray, Ship.all.toArray), delta)
  }
}
