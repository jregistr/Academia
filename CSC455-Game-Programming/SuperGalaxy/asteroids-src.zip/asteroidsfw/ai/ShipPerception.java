package asteroidsfw.ai;

import asteroidsfw.Vector2d;

public interface ShipPerception {
  //position
  public Vector2d pos();
  //velocity
  public Vector2d v();
  //direction is a unit vector (length 1)
  public Vector2d direction();
  //number of seconds until the ship can move. If negative, the ship can move.
  public double respawnIn();
  //number of seconds until the ship can shoot. If negative, the ship can shoot.
  public double shotCoolDown();
  //radius of the bounding circle (used for collision checks) of the ship
  public int radius();
}
