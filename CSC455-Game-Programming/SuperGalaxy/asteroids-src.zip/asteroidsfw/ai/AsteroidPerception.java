package asteroidsfw.ai;

import asteroidsfw.Vector2d;

public interface AsteroidPerception {
  public Vector2d pos();
  public Vector2d v();
  public int radius();
}
