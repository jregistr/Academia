package asteroidsfw.ai;

public interface ShipMind {
  public void init(ShipControl control);
  public void think(Perceptions percepts, double delta);
}
