package asteroidsfw

object Ship {
  val all = scala.collection.mutable.Set[Ship]()
  val maxAngle: Double = 4 //max rotation per second in radians
  val thrustPerS: Double = 100
  val coolDownSecs: Double = 2
  val respawnSecs: Double = 10
}

class Ship extends CollidableCircle with Movable with ai.ShipControl {
  @volatile var score = 0

  Ship.all += this

  val radius = 10 //r of the bounding circle
  @volatile var v = Vector2d(0, 0)
  @volatile var pos = Vector2d(Game.hRes / 2, Game.vRes / 2)
  @volatile var direction = Vector2d(1, 0)
  @volatile var shotCoolDown: Double = Ship.coolDownSecs
  @volatile var respawnIn: Double = 0

  @volatile private var _rotateLeft: Boolean = false
  @volatile private var _rotateRight: Boolean = false
  @volatile private var _thrustForward: Boolean = false
  @volatile private var _thrustBackward: Boolean = false
  @volatile private var _shooting: Boolean = false

  def rotateLeft(b: Boolean) { _rotateLeft = b }
  def rotateRight(b: Boolean) { _rotateRight = b }
  def thrustForward(b: Boolean) { _thrustForward = b }
  def thrustBackward(b: Boolean) { _thrustBackward = b }
  def shooting(b: Boolean) { _shooting = b }

  private def die() {
    pos = Vector2d(Game.hRes / 2, Game.vRes / 2)
    v = Vector2d(0, 0)
    respawnIn = Ship.respawnSecs
  }

  private def rotate(dt: Double) {
    if (!(_rotateLeft ^ _rotateRight)) return
    val angle = dt *
      (if (_rotateRight)
        Ship.maxAngle
      else
        -Ship.maxAngle)
    direction = direction rotate angle
  }

  private def thrust(dt: Double) {
    if (!(_thrustForward ^ _thrustBackward)) return
    val thr = dt *
      (if (_thrustForward)
        Ship.thrustPerS
      else
        -Ship.thrustPerS)
    v += direction * thr
    clampSpeed()
  }

  private def shoot(dt: Double) {
    shotCoolDown -= dt
    if (_shooting && shotCoolDown <= 0) {
      shotCoolDown = Ship.coolDownSecs
      Game.create.bullet(this, pos + direction * 14, v + direction * 150)
    }
  }

  override def move(dt: Double) {
    respawnIn -= dt
    if (respawnIn <= 0) {
      rotate(dt)
      thrust(dt)
      shoot(dt)
      super.move(dt)
    }
  }

  def collide(other: Collidable) {
    other match {
      case that: Asteroid => die()
      case that: Bullet => that collide this
      case _ =>
    }
  }

  override def destroy() {
    throw new RuntimeException("Ships are not supposed to be destroyed.")
  }
}
