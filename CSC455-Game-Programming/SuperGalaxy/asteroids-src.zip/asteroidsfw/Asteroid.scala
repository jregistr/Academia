package asteroidsfw

object Asteroid {
  val all = scala.collection.mutable.Set[Asteroid]()
}

abstract class Asteroid(val radius: Int) extends CollidableCircle with ai.AsteroidPerception with Movable {
  val hitScore: Int
  private var dead = false
  Asteroid.all += this

  private def bounceAsteroid(that: Asteroid) {
//calculate and normalize the X-axis (perpendicular to the collision plane)
    var normAxis = (pos - that.pos).normalize
//calculate the parallel (x) and perpendicular (y) components of v respective to the X-axis
    val v1x = normAxis * (normAxis dot v)
    val v1y = v - v1x
//force a double for the mass, otherwise 1/2 == 0 later
    val m1: Double = radius * radius

//same here, only reverse the X-axis
    normAxis = -normAxis
    val v2x = normAxis * (normAxis dot that.v)
    val v2y = that.v - v2x
    val m2: Double = that.radius * that.radius

//plug the components into the elastic collision formula (the x components of the velocities change, the y ones are the same)
    v = v1x * ((m1 - m2) / (m1 + m2)) + v2x * (2 * m2 / (m1 + m2)) + v1y
    clampSpeed()
    that.v = v1x * (2 * m1 / (m1 + m2)) + v2x * ((m2 - m1) / (m1 + m2)) + v2y
    that.clampSpeed()
  }

  private def bounceStation(that: SpaceStation) {
    val normAxis = (pos - that.pos).normalize
    val vx = normAxis * (normAxis dot v)
    val vy = v - vx
    v = -vx + vy
  }

  protected def split()

  def collide(other: Collidable) {
    other match {
      case that: Asteroid => bounceAsteroid(that)
      case that: SpaceStation => bounceStation(that)
      case that: Bullet => {
        that.parent.score += hitScore
        that.destroy()
        if (!dead) {
          split()
          destroy()
        }
        dead = true
      }
      case that: Ship => that collide this
      case _ =>
    }
  }

  override def destroy() {
    Asteroid.all -= this
    super.destroy()
  }
}

class SmallAsteroid(@volatile var pos: Vector2d, @volatile var v: Vector2d) extends Asteroid(5) {
  val hitScore = 9

  protected def split() {} //don't split smallest asteroid
}

class MediumAsteroid(@volatile var pos: Vector2d, @volatile var v: Vector2d) extends Asteroid(10) {
  val hitScore = 3

  protected def split() {
    Game.create.smallAsteroid(pos + Vector2d(5, 0), v rotate Math.random)
    Game.create.smallAsteroid(pos + Vector2d(-5, 0), v rotate -Math.random)
  }
}

class LargeAsteroid(@volatile var pos: Vector2d, @volatile var v: Vector2d) extends Asteroid(20) {
  val hitScore = 1

  protected def split() {
    Game.create.mediumAsteroid(pos + Vector2d(10, 0), v rotate Math.random)
    Game.create.mediumAsteroid(pos + Vector2d(-10, 0), v rotate -Math.random)
  }
}
