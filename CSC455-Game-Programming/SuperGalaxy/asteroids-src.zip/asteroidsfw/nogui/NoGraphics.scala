package asteroidsfw.nogui

object NoGraphics extends GraphicsSubSystem {
  override def update(delta: Double) {}
}
