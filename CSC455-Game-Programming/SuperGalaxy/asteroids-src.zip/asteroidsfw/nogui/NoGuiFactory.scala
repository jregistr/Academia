package asteroidsfw.nogui

object NoGuiFactory extends GameObjectFactory {
  def ship(aiControlled: Boolean, shipColor: String): Ship = new Ship
  def spaceStation: SpaceStation = new SpaceStation
  def bullet(parent: Ship, pos: Vector2d, v: Vector2d): Bullet = new Bullet(parent, pos, v)
  def smallAsteroid(pos: Vector2d, v: Vector2d): Asteroid = new SmallAsteroid(pos, v)
  def mediumAsteroid(pos: Vector2d, v: Vector2d): Asteroid = new MediumAsteroid(pos, v)
  def largeAsteroid(pos: Vector2d, v: Vector2d): Asteroid = new LargeAsteroid(pos, v)
}
