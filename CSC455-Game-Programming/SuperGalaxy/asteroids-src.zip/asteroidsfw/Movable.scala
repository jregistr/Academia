package asteroidsfw

object Movable extends GameSubSystem[Movable] {
  val maxSpeed = 100

  def update(delta: Double) {
    all.foreach(_.move(delta))
  }
}

trait Movable extends GameObject {
  var v: Vector2d

  Movable + this

  override def destroy() {
    Movable - this
    super.destroy()
  }

  def move(dt: Double) {
    pos += v * dt
    if (pos.x < 0) pos += Vector2d(Game.hRes, 0)
    if (pos.x > Game.hRes) pos -= Vector2d(Game.hRes, 0)
    if (pos.y < 0) pos += Vector2d(0, Game.vRes)
    if (pos.y > Game.vRes) pos -= Vector2d(0, Game.vRes)
  }

  protected def clampSpeed() {
    if (v.sqLength > Movable.maxSpeed * Movable.maxSpeed)
      v = v.normalize * Movable.maxSpeed
  }
}
