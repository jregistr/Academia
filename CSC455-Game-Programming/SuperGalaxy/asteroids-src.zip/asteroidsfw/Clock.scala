package asteroidsfw

object Clock {
  private var clocks: List[Clock] = Nil
  private var absoluteLast: Long = _
  private var absoluteCurrent: Long = _
  val cyclesPerSecond: Double = 1000000000 //internal time unit is 1ns

  def secondsToCycles(seconds: Double): Long =
    (seconds * cyclesPerSecond).toLong
  def cyclesToSeconds(cycles: Long): Double =
    cycles / cyclesPerSecond

  //there should be a method to remove/discard clocks, too
  def apply(startSeconds: Double): Clock = {
    val c = new Clock(startSeconds)
    clocks ::= c
    c
  }

  //should be called just before the main loop. Updates time without messaging clocks
  def update() {
    absoluteCurrent = System.nanoTime
  }

  //should be called every main loop iteration
  def tick() {
    absoluteLast = absoluteCurrent
    update()
    clocks.foreach(_.tick(absoluteCurrent - absoluteLast))
  }
}

class Clock private(startSeconds: Double) {
  private var current: Long = _
  var scale: Double = 1.0
  var paused: Boolean = false
  set(startSeconds)

  private def tick(delta: Long) {
    if (!paused)
      current += (delta * scale).toLong
  }

  def time: Double = Clock.cyclesToSeconds(current)

  def set(newValue: Double) {
    current = Clock.secondsToCycles(newValue)
  }

  def -(other: Clock): Double =
    this.time - other.time

  override def toString = 
    "Clock time: " + time + ", paused: " + paused + ", scale: " + scale
}
