package asteroidsfw

abstract class GraphicsSubSystem extends GameSubSystem[GraphicsObject] {
  def update(delta: Double) {
    all.foreach(_.render())
  }
}

trait GraphicsObject extends GameObject {
  Game.graphics + this

  override def destroy() {
    Game.graphics - this
    super.destroy()
  }

  def render(): Unit
}
