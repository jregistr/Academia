package asteroidsfw

import ai.AISubSystem
import ai.ShipMind

object Game {
  val hRes = 800
  val vRes = 600
  var frameDuration: Double = 1000.0 / 30.0
  val mainClock = Clock(0)
  val elapsedClock = Clock(0)
  var quitting = false
  var period = Math.MAX_INT
  var quitClock: Option[Clock] = None

/*  val graphics: GraphicsSubSystem = java2d.Java2dGraphics
  val create: GameObjectFactory = java2d.Java2dFactory
  */
  var graphics: GraphicsSubSystem = _
  var create: GameObjectFactory = _
  var station: SpaceStation = _
  var stageCount = 0

  def main(args: Array[String]) {
    def setGLGraphics() {
      graphics = lwjgl.GLGraphics
      create = lwjgl.GLFactory
    }

    def setJ2DGraphics() {
      graphics = java2d.Java2dGraphics
      create = java2d.Java2dFactory
    }

    def setNoGraphics() {
      graphics = nogui.NoGraphics
      create = nogui.NoGuiFactory
    }

    //args: graphics, frame rate, which graphics to use, ships and minds
    args.find(_.startsWith("gui")) match {
      case Some(s) => s.split("=")(1) match {
        case "java2d" => setJ2DGraphics()
        case "none" => setNoGraphics()
        case _ => setGLGraphics()
      }
      case None => setGLGraphics()
    }

    args.foreach(processArgument)
    station = create.spaceStation
    loop()
    graphics.shutdown()
    AISubSystem.shutdown()
  }

  def newStage(num: Int) {
    for (i <- 0 until num; j <- 0 until num)
      create.largeAsteroid(Vector2d(120 * i, 120 * j), Vector2d(80 * Math.random, 80 * Math.random))
  }

  def processArgument(arg: String) {
    val splitArg = arg.split("=")
    splitArg(0) match {
      case "file" =>
        for (line <- scala.io.Source.fromFile(splitArg(1)).getLines)
          processArgument(line.trim())
      case "ship" => processShip(splitArg(1).trim())
      case "period" => period = splitArg(1).toInt
      case "fps" => frameDuration = 1000.0 / splitArg(1).toInt
      case "quit" => {
        quitClock = Some(Clock(splitArg(1).toInt))
        quitClock.get.scale = -1
      }
/*      case "gui" => splitArg(1) match {
        case "java2d" => 
          graphics = java2d.Java2dGraphics
          create = java2d.Java2dFactory
        case _ =>
          graphics = lwjgl.GLGraphics
          create = lwjgl.GLFactory
      }
      */
      case _ =>
    }
  }

  def processShip(arg: String) {
    val splitArg = arg.split("[,;]")
    if (splitArg(0) == "human")
      create.ship(false, splitArg(1))
    else {
      val mind = Class.forName(splitArg(0)).newInstance().asInstanceOf[ShipMind]
      AISubSystem + mind
      mind.init(create.ship(true,splitArg(1)))
    }
  }

  def loop() {
    var lastTime = mainClock.time
    Clock.update()
    while (!quitting && quitClock.forall(_.time > 0)) {
/*           (quitClock match {
             case None => true
             case Some(c) => c.time > 0
           })
    ) { */
      if (elapsedClock.time > period) {
        mainClock.paused = true
        elapsedClock.paused = true
      }

      if (Asteroid.all.size == 0) {
        stageCount += 1
        newStage(stageCount)
      }

      Clock.tick()

      val currentTime = mainClock.time
      val delta = currentTime - lastTime
      lastTime = currentTime
      Movable.update(delta)
      Collidable.update(delta)
      graphics.update(delta)
      AISubSystem.update(delta)

//needs time update for correct sleep value
      Clock.tick()

      val sleepValue = frameDuration - ((mainClock.time - lastTime) * 1000)
      if (sleepValue > 0)
        Thread.sleep(sleepValue.toLong)
    }
  }
}
