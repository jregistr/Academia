package asteroidsfw

import scala.collection.mutable.Set

abstract class GameSubSystem[T] {
  protected val all = Set[T]()

  def + (item: T) {
    all += item
  }

  def - (item: T) {
    all -= item
  }

  def update(delta: Double): Unit
  def shutdown() {}
}

abstract class GameObject {
  var pos: Vector2d

  def destroy() {}
}

trait GameObjectFactory {
  def ship(aiControlled: Boolean, visual: String): Ship
  def spaceStation: SpaceStation
  def bullet(parent: Ship, pos: Vector2d, v: Vector2d): Bullet
  def smallAsteroid(pos: Vector2d, v: Vector2d): Asteroid
  def mediumAsteroid(pos: Vector2d, v: Vector2d): Asteroid
  def largeAsteroid(pos: Vector2d, v: Vector2d): Asteroid
}
