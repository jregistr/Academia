package asteroidsfw

class SpaceStation extends CollidableCircle {
  var pos = new Vector2d(Game.hRes / 2, Game.vRes / 2)
  val radius = 20
  
  def collide(other: Collidable) {
    other match {
      case that: SpaceStation =>
      case _ => other collide this
    }
  }
}
