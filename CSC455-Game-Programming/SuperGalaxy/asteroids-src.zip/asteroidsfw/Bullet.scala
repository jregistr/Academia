package asteroidsfw

class Bullet(val parent: Ship, var pos: Vector2d, var v: Vector2d) extends CollidableCircle with Movable {
  val radius = 2
  var lifeSeconds: Double = 10

  def collide(other: Collidable) {
    other match {
      case that: Ship => this.destroy()
      case that: SpaceStation => this.destroy()
      case that: Asteroid => other collide this
      case _ =>
    }
  }

  override def move(dt: Double) {
    lifeSeconds -= dt
    if (lifeSeconds <= 0)
      this.destroy()
    else
      super.move(dt)
  }
}
