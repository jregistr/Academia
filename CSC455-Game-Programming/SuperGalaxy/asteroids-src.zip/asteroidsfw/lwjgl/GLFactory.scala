package asteroidsfw.lwjgl

import asteroidsfw._

object GLFactory extends GameObjectFactory {

  def ship(aiControlled: Boolean, shipColor: String): Ship = {
    var s: Ship with ShipGraphics = null
    if (aiControlled)
      s = new Ship with ShipGraphics
    else
      s = new Ship with ShipGraphics with ShipControl
    s.setColors(Integer.decode(shipColor).intValue)
    s
  }

  def spaceStation: SpaceStation = new SpaceStation with SpaceStationGraphics
  def bullet(parent: Ship, pos: Vector2d, v: Vector2d): Bullet = new Bullet(parent, pos, v) with BulletGraphics
  def smallAsteroid(pos: Vector2d, v: Vector2d): Asteroid = new SmallAsteroid(pos, v) with AsteroidGraphics 
  def mediumAsteroid(pos: Vector2d, v: Vector2d): Asteroid = new MediumAsteroid(pos, v) with AsteroidGraphics 
  def largeAsteroid(pos: Vector2d, v: Vector2d): Asteroid = new LargeAsteroid(pos, v) with AsteroidGraphics 
}
