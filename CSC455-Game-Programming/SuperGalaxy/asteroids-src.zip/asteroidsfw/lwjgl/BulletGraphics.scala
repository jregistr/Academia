package asteroidsfw.lwjgl

import org.lwjgl.opengl.GL11
import org.newdawn.asteroids.particles.ParticleGroup
import org.newdawn.spaceinvaders.lwjgl.Texture

trait BulletGraphics extends GraphicsObject {
  this: Bullet =>

  val parentG = parent.asInstanceOf[ShipGraphics]

  val size = 0.35f
  val particles = new ParticleGroup(3,10,parentG.red,parentG.green,parentG.blue)

  def render() {
    particles.addParticle(GLGraphics.convertXToGL(pos.x), GLGraphics.convertYToGL(pos.y), size, 200)
    particles.update(1)
    GL11.glDisable(GL11.GL_LIGHTING)
    GL11.glEnable(GL11.GL_BLEND)
    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE)
    GLGraphics.shotTexture.bind()
    particles.render()
    GL11.glDisable(GL11.GL_BLEND)
  }
}
