package asteroidsfw.lwjgl

import java.nio.FloatBuffer
import org.lwjgl._
import org.lwjgl.opengl._
import org.lwjgl.input.Keyboard
import org.lwjgl.util.glu.GLU
import org.newdawn.spaceinvaders.lwjgl._
import org.newdawn.asteroids.model._
import org.newdawn.asteroids.gui._

object GLGraphics extends GraphicsSubSystem {
  val glWidth: Float = 55
  val halfWidth = glWidth / 2
  val glHeight: Float = 42
  val halfHeight = glHeight / 2
  val hTrans = Game.hRes.toFloat / glWidth
  val vTrans = Game.vRes.toFloat / glHeight

  val mode = findDisplayMode(Game.hRes, Game.vRes, Display.getDisplayMode.getBitsPerPixel)
  Display.setTitle("Asteroids OpenGL Graphics")
  Display.setDisplayMode(mode)
  Display.setFullscreen(false)
  Display.create()

  GL11.glEnable(GL11.GL_TEXTURE_2D)
  GL11.glEnable(GL11.GL_CULL_FACE)
  GL11.glEnable(GL11.GL_DEPTH_TEST)
  GL11.glDepthFunc(GL11.GL_LEQUAL)
  GL11.glShadeModel(GL11.GL_SMOOTH)  

  GL11.glMatrixMode(GL11.GL_PROJECTION)
  GL11.glLoadIdentity()		
  GLU.gluPerspective(45.0f, Game.hRes.toFloat / Game.vRes, 0.1f, 100.0f)
  GL11.glMatrixMode(GL11.GL_MODELVIEW)
  GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST) 

  val material = defineLight

  val loader = new TextureLoader
  val background = loader.getTexture("res/bg.jpg")
  val shotTexture = loader.getTexture("res/shot.png")
  val fontTexture = loader.getTexture("res/font.png")
  val font = new BitmapFont(fontTexture, 32, 32)

  private def findDisplayMode(h: Int, v: Int, bpp: Int): DisplayMode = {
    val modes = Display.getAvailableDisplayModes
    var retValue: DisplayMode = null
    for (mode <- modes)
      if (mode.getBitsPerPixel == bpp || retValue == null)
        if (mode.getWidth == h && mode.getHeight == v)
          retValue = mode
    return retValue
  }

  private def defineLight(): FloatBuffer = {
    var buffer: FloatBuffer = null

    buffer = BufferUtils.createFloatBuffer(4)
    buffer.put(2).put(2).put(2).put(2) 
    buffer.flip()
    GL11.glLight(GL11.GL_LIGHT0, GL11.GL_AMBIENT, buffer)

    buffer = BufferUtils.createFloatBuffer(4)
    buffer.put(1).put(1).put(1).put(1)
    buffer.flip()
    GL11.glLight(GL11.GL_LIGHT0, GL11.GL_DIFFUSE, buffer)

    // setup the ambient light 
    buffer = BufferUtils.createFloatBuffer(4)
    buffer.put(0.8f).put(0.8f).put(0.8f).put(0.8f)
    buffer.flip()
    GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, buffer)
    GL11.glLightModeli(GL11.GL_LIGHT_MODEL_TWO_SIDE, GL11.GL_TRUE)

    // set up the position of the light
    buffer = BufferUtils.createFloatBuffer(4)
    buffer.put(10).put(10).put(5).put(0)
    buffer.flip()
    GL11.glLight(GL11.GL_LIGHT0, GL11.GL_POSITION, buffer)

    GL11.glEnable(GL11.GL_LIGHT0)

    return BufferUtils.createFloatBuffer(4)
  }

  private def enterOrtho() {
// store the current state of the renderer
    GL11.glPushAttrib(GL11.GL_DEPTH_BUFFER_BIT | GL11.GL_ENABLE_BIT)
    GL11.glPushMatrix()
    GL11.glLoadIdentity()
    GL11.glMatrixMode(GL11.GL_PROJECTION) 
    GL11.glPushMatrix()	

    // now enter orthographic projection
    GL11.glLoadIdentity()		
    GL11.glOrtho(0, Game.hRes, Game.vRes, 0, -1, 1)
    GL11.glDisable(GL11.GL_DEPTH_TEST)
    GL11.glDisable(GL11.GL_LIGHTING)  
  }

  private def leaveOrtho() {
    // restore the state of the renderer
    GL11.glPopMatrix()
    GL11.glMatrixMode(GL11.GL_MODELVIEW)
    GL11.glPopMatrix()
    GL11.glPopAttrib()
  }

  private def drawBackground() {
    enterOrtho()
    background.bind()

    GL11.glBegin(GL11.GL_QUADS)
    GL11.glTexCoord2f(0,0)
    GL11.glVertex2i(0,0)
    GL11.glTexCoord2f(0,1)
    GL11.glVertex2i(0,Game.vRes)
    GL11.glTexCoord2f(1,1)
    GL11.glVertex2i(Game.hRes,Game.vRes)
    GL11.glTexCoord2f(1,0)
    GL11.glVertex2i(Game.hRes,0)
    GL11.glEnd()

    leaveOrtho()
  }

  private def drawGUI() {
    enterOrtho()
    GL11.glColor3f(0.4f, 0.4f, 0.4f)
    val tm = Game.elapsedClock.time.toLong.toString
    font.drawString(1, tm, Game.hRes - 10 - 27 * tm.length, 5)
    var vertOffset = 5
    for (ship <- Ship.all) {
      val shipG = ship.asInstanceOf[ShipGraphics]
      GL11.glColor3f(shipG.red, shipG.green, shipG.blue)
      font.drawString(1, ship.score.toString, 5, vertOffset)
      vertOffset += 30
    }
    GL11.glColor3f(1, 1, 1)
    leaveOrtho()
  }

  private def checkMainKeys() {
    while (Keyboard.next())
      if (Keyboard.getEventKeyState()) Keyboard.getEventKey match {
        case Keyboard.KEY_Q => Game.quitting = true
        case Keyboard.KEY_P =>
          Game.mainClock.paused = !Game.mainClock.paused
          Game.elapsedClock.paused = !Game.elapsedClock.paused
        case Keyboard.KEY_C => Game.period = Math.MAX_INT
        case Keyboard.KEY_ADD => Game.mainClock.scale += 1
        case Keyboard.KEY_SUBTRACT => Game.mainClock.scale -= 1
        case _ =>
      }
  }

  override def update(dt: Double) {
    GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT)
    GL11.glLoadIdentity()

    material.put(1).put(1).put(1).put(1) 
    material.flip()
    GL11.glMaterial(GL11.GL_FRONT, GL11.GL_DIFFUSE, material)
    GL11.glMaterial(GL11.GL_BACK, GL11.GL_DIFFUSE, material)

    // draw our background image
    GL11.glDisable(GL11.GL_LIGHTING)
//    drawBackground()

    // position the view a way back from the models so we
    // can see them
    GL11.glTranslatef(0,0,-50)

    // render all game objects
    super.update(dt)

    //render the score overlay
    drawGUI()

    Display.update()
    checkMainKeys()
    if (Display.isCloseRequested) Game.quitting = true
  }

  def convertXToGL(x: Double): Float = 
    x.toFloat / hTrans - halfWidth

  def convertYToGL(y: Double): Float = 
    -y.toFloat / vTrans + halfHeight

  override def shutdown() {
  }
}
