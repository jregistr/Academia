package asteroidsfw.lwjgl

import org.lwjgl.opengl.GL11
import org.newdawn.asteroids.model.ObjLoader

object AsteroidGraphics {
  val texture = GLGraphics.loader.getTexture("res/rock.jpg")
  val model = ObjLoader.loadObj("res/rock.obj")
  val scale = 0.12f
}

trait AsteroidGraphics extends GraphicsObject with Movable with Collidable {
  this: Asteroid =>

  val glScale = AsteroidGraphics.scale * radius
  var rotationSpeed = (Math.random * 60) + 1
  var rotation: Float = 0

  def render() {
    GL11.glEnable(GL11.GL_LIGHTING)
    GL11.glPushMatrix()
    GL11.glTranslatef(GLGraphics.convertXToGL(pos.x), GLGraphics.convertYToGL(pos.y), 0)
    GL11.glRotatef(rotation, 0, 0, 1)
    GL11.glScalef(glScale, glScale, glScale)
    AsteroidGraphics.texture.bind()
    AsteroidGraphics.model.render()
    GL11.glPopMatrix()
  }

  override def move(dt: Double) {
    rotation += (dt * rotationSpeed).toFloat
    super.move(dt)
  }

  abstract override def collide(other: Collidable) {
    rotationSpeed = -rotationSpeed
    super.collide(other)
  }
}
