package asteroidsfw.lwjgl

import org.lwjgl.opengl.GL11
import org.newdawn.asteroids.model.ObjLoader
import org.newdawn.asteroids.particles.ParticleGroup

object ShipGraphics {
  val texture = GLGraphics.loader.getTexture("res/ship.jpg")
  val model = ObjLoader.loadObj("res/ship.obj")
  //model's rotation offset from the ship's one in degrees
  val rotOffset = 90f
  val exhOffset = 0.001
  val exhSize = 0.9f
}

trait ShipGraphics extends GraphicsObject {
  this: Ship =>

  var exhaust: ParticleGroup = _
  var red: Float = 0
  var green: Float = 0
  var blue: Float = 0

  def render() {
    GL11.glEnable(GL11.GL_LIGHTING)
    GL11.glPushMatrix()
    GL11.glTranslatef(GLGraphics.convertXToGL(pos.x), GLGraphics.convertYToGL(pos.y), 0)
    GL11.glRotatef(-(Math.atan2(direction.y, direction.x)* 180 / java.lang.Math.PI).toFloat + ShipGraphics.rotOffset,0,0,1)
    //align the model axis to the world one
		GL11.glRotatef(90,1,0,0);
    GL11.glScalef(0.005f, 0.005f, 0.005f)
    ShipGraphics.texture.bind()
    ShipGraphics.model.render()
    GL11.glPopMatrix()
    renderExhaust()
  }

  def renderExhaust() {
    val particle = pos - direction * v.sqLength * ShipGraphics.exhOffset
    exhaust.addParticle(GLGraphics.convertXToGL(particle.x), GLGraphics.convertYToGL(particle.y), ShipGraphics.exhSize, 10)
    exhaust.update(1)

    GL11.glDisable(GL11.GL_LIGHTING)
    GL11.glEnable(GL11.GL_BLEND)
    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE)
    GLGraphics.shotTexture.bind()
    exhaust.render()
    GL11.glDisable(GL11.GL_BLEND)
  }

  def setColors(color: Int) {
    blue = (color & 0xff) / 255.0f
    green = ((color >> 8) & 0xff) / 255.0f
    red = ((color >> 16) & 0xff) / 255.0f
    exhaust = new ParticleGroup(10, 10, red, green, blue)
  }
}
