package asteroidsfw.lwjgl

import org.lwjgl.opengl.GL11
import org.lwjgl.util.glu._
import org.newdawn.asteroids.particles.ParticleGroup

trait SpaceStationGraphics extends GraphicsObject {
  this: SpaceStation =>
  val sphere = new Sphere

  val particles = new ParticleGroup(3, 1, 0, 1, 0)
  val size = 1.3f
  def render() {
    particles.addParticle(0, 0, size, 200)
    particles.update(1)
    GL11.glDisable(GL11.GL_LIGHTING)
    GL11.glEnable(GL11.GL_BLEND)
    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE)
    GLGraphics.shotTexture.bind()
    particles.render()
    GL11.glDisable(GL11.GL_BLEND)
  }

}
