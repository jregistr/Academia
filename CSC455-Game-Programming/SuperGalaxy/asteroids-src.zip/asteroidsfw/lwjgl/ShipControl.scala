package asteroidsfw.lwjgl

import org.lwjgl.input.Keyboard

trait ShipControl extends Movable {
  this: Ship =>

  override def move(dt: Double) {
    if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) rotateLeft(true)
    else rotateLeft(false)
    if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) rotateRight(true)
    else rotateRight(false)
    if (Keyboard.isKeyDown(Keyboard.KEY_UP)) thrustForward(true)
    else thrustForward(false)
    if (Keyboard.isKeyDown(Keyboard.KEY_DOWN)) thrustBackward(true)
    else thrustBackward(false)
    if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) shooting(true)
    else shooting(false)

    super.move(dt)
  }
}
