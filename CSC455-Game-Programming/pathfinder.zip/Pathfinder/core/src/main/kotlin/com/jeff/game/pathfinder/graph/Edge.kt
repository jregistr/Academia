package com.jeff.game.pathfinder.graph


data class Edge(val from: Node, val to: Node)