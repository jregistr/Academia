var Maths = (function(){
   
    return {
        
        degToRad:function(){
            return angle * Math.PI / 180.0
        }
    }
    
})()