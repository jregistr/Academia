package RatingInfo;


public class LoginSave {
    public String ID;
    public String userName;
    public String passWord;
    public String fullName;

    public LoginSave(String un,String pw,String fn,String id){
        ID = id;
        userName = un;
        passWord = pw;
        fullName = fn;
    }
}
